#ifndef _dist_corr
#define _dist_corr

//#include <boost/numeric/conversion/cast.hpp> 
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_rng.h>

using namespace std;

class dist_corr {
	public:
		dist_corr(){  }; //default constructor
		~dist_corr () { };//default destructor
		double dcorr_stat (Matrix, Matrix);//the distance correlation statistic eq. (2.4)
	private:
		
};

double dist_corr::dcorr_stat (Matrix X, Matrix epsilon)
{
	
}


#endif
