#include <iostream>
#include <fstream>
#include <iomanip>   // format manipulation
#include <string>
#include <sstream>
#include <cstdlib>
#include <math.h>
#include <cmath>
#include <gsl/gsl_math.h>
#include <stdio.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_errno.h>
#include <gsl/gsl_multimin.h>
#include <vector> // C++ vector class
#include <algorithm>
#include <functional>
#include <gsl/gsl_randist.h>
#include <boost/numeric/conversion/cast.hpp>
#include <gsl/gsl_rng.h>
#include <filein.h>
#include <limits>
#include <float.h>
#include <time.h>
#include <sys/time.h>
//#include <windows.h>
#include <omp.h>
#include <matrix_ops2.h>
#include <dist_corr.h>





using namespace std;

//void (*aktfgv)(double *,double *,int *,int *,void *,Matrix&);

int main(void) {
	
	//start the timer%%%%%
	double time = 0.0, timelast = 0.0;
    time = ((double) clock())/((double) CLOCKS_PER_SEC);
    timelast = time;
    ofstream output;
    output.open("file.txt", ios::out);
    cout << "testing..." << endl;
    //===============================================================================================================//
    //please do not comment out the lines below.
    time = ((double) clock())/((double) CLOCKS_PER_SEC);
    output << "Elapsed time = " << (time-timelast)/60 << " minutes" << endl;
    output.close();
    system("PAUSE");
    return 0;
}






